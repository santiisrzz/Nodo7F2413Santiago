import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.Collectors;

// Clase para representar un producto
class Producto {
    private String nombre;
    private double precio;
    private int cantidad;
    private String categoria;

    public Producto(String nombre, double precio, int cantidad, String categoria) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
        this.categoria = categoria;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public String getCategoria() {
        return categoria;
    }

    // Método para reducir la cantidad cuando se realiza una venta
    public void reducirCantidad(int cantidadVendida) {
        if (cantidad >= cantidadVendida) {
            this.cantidad -= cantidadVendida;
        } else {
            System.out.println("Cantidad insuficiente en stock.");
        }
    }

    @Override
    public String toString() {
        return "Producto: " + nombre + " | Precio: " + precio + " | Cantidad: " + cantidad + " | Categoría: " + categoria;
    }
}

// Clase para gestionar el inventario
class Inventario {
    private ArrayList<Producto> productos;

    public Inventario() {
        productos = new ArrayList<>();
    }

    // Método para agregar un nuevo producto
    public void agregarProducto(String nombre, double precio, int cantidad, String categoria) {
        productos.add(new Producto(nombre, precio, cantidad, categoria));
        System.out.println("Producto agregado: " + nombre);
    }

    // Método para realizar una venta y actualizar la cantidad
    public void realizarVenta(String nombreProducto, int cantidadVendida) {
        for (Producto producto : productos) {
            if (producto.getNombre().equalsIgnoreCase(nombreProducto)) {
                producto.reducirCantidad(cantidadVendida);
                System.out.println("Venta realizada: " + cantidadVendida + " de " + nombreProducto);
                return;
            }
        }
        System.out.println("Producto no encontrado.");
    }

    // Método para consultar productos por categoría
    public void consultarPorCategoria(String categoria) {
        System.out.println("\nProductos en la categoría " + categoria + ":");
        for (Producto producto : productos) {
            if (producto.getCategoria().equalsIgnoreCase(categoria)) {
                System.out.println(producto);
            }
        }
    }

    // Método para consultar productos dentro de un rango de precios
    public void consultarPorPrecio(double precioMin, double precioMax) {
        System.out.println("\nProductos en el rango de precio " + precioMin + " - " + precioMax + ":");
        for (Producto producto : productos) {
            if (producto.getPrecio() >= precioMin && producto.getPrecio() <= precioMax) {
                System.out.println(producto);
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Inventario inventario = new Inventario();

        while (true) {
            System.out.println("\n--- Menú de Gestión de Inventario ---");
            System.out.println("1. Agregar Producto");
            System.out.println("2. Realizar Venta");
            System.out.println("3. Consultar Productos por Categoría");
            System.out.println("4. Consultar Productos por Precio");
            System.out.println("5. Salir");
            System.out.print("Elige una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    System.out.print("Ingresa el nombre del producto: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingresa el precio del producto: ");
                    double precio = scanner.nextDouble();
                    System.out.print("Ingresa la cantidad disponible: ");
                    int cantidad = scanner.nextInt();
                    scanner.nextLine(); // Limpiar el buffer
                    System.out.print("Ingresa la categoría del producto: ");
                    String categoria = scanner.nextLine();
                    inventario.agregarProducto(nombre, precio, cantidad, categoria);
                    break;
                case 2:
                    System.out.print("Ingresa el nombre del producto a vender: ");
                    String nombreProducto = scanner.nextLine();
                    System.out.print("Ingresa la cantidad a vender: ");
                    int cantidadVendida = scanner.nextInt();
                    inventario.realizarVenta(nombreProducto, cantidadVendida);
                    break;
                case 3:
                    System.out.print("Ingresa la categoría a consultar: ");
                    String categoriaConsulta = scanner.nextLine();
                    inventario.consultarPorCategoria(categoriaConsulta);
                    break;
                case 4:
                    System.out.print("Ingresa el precio mínimo: ");
                    double precioMin = scanner.nextDouble();
                    System.out.print("Ingresa el precio máximo: ");
                    double precioMax = scanner.nextDouble();
                    inventario.consultarPorPrecio(precioMin, precioMax);
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }
}
