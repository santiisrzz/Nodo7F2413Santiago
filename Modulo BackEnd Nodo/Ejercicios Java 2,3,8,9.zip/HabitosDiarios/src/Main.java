import java.util.ArrayList;
import java.util.Scanner;

// Clase para representar un hábito
class Habito {
    private String nombre;
    private int progreso;

    public Habito(String nombre) {
        this.nombre = nombre;
        this.progreso = 0; // Progreso inicial
    }

    public String getNombre() {
        return nombre;
    }

    public int getProgreso() {
        return progreso;
    }

    // Método para incrementar el progreso
    public void incrementarProgreso() {
        this.progreso++;
    }
}

// Clase principal para gestionar los hábitos
class SeguimientoHabitos {
    private ArrayList<Habito> habitos;

    public SeguimientoHabitos() {
        habitos = new ArrayList<>();
    }

    // Agregar un nuevo hábito
    public void agregarHabito(String nombre) {
        habitos.add(new Habito(nombre));
        System.out.println("Hábito agregado: " + nombre);
    }

    // Registrar el progreso de un hábito
    public void registrarProgreso(String nombreHabito) {
        for (Habito habito : habitos) {
            if (habito.getNombre().equalsIgnoreCase(nombreHabito)) {
                habito.incrementarProgreso();
                System.out.println("Progreso registrado para: " + nombreHabito);
                return;
            }
        }
        System.out.println("Hábito no encontrado.");
    }

    // Mostrar resumen de hábitos
    public void mostrarResumen() {
        System.out.println("\nResumen de Hábitos:");
        for (Habito habito : habitos) {
            System.out.println("Hábito: " + habito.getNombre() + " | Progreso: " + habito.getProgreso());
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SeguimientoHabitos seguimientoHabitos = new SeguimientoHabitos();

        while (true) {
            System.out.println("\n--- Menú de Seguimiento de Hábitos ---");
            System.out.println("1. Agregar Hábito");
            System.out.println("2. Registrar Progreso");
            System.out.println("3. Mostrar Resumen");
            System.out.println("4. Salir");
            System.out.print("Elige una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    System.out.print("Ingresa el nombre del hábito: ");
                    String nombreHabito = scanner.nextLine();
                    seguimientoHabitos.agregarHabito(nombreHabito);
                    break;
                case 2:
                    System.out.print("Ingresa el nombre del hábito para registrar progreso: ");
                    String nombre = scanner.nextLine();
                    seguimientoHabitos.registrarProgreso(nombre);
                    break;
                case 3:
                    seguimientoHabitos.mostrarResumen();
                    break;
                case 4:
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }
}
