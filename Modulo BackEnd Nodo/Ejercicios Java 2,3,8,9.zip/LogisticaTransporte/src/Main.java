import java.util.ArrayList;
import java.util.Scanner;

// Clase para representar un envío
class Envio {
    private String numeroEnvio;
    private String destino;
    private double distancia;  // en kilómetros
    private double peso;       // en kilogramos
    private double costo;
    private String estado;      // Estado del envío (en tránsito, entregado, etc.)

    public Envio(String numeroEnvio, String destino, double distancia, double peso) {
        this.numeroEnvio = numeroEnvio;
        this.destino = destino;
        this.distancia = distancia;
        this.peso = peso;
        this.costo = calcularCosto();
        this.estado = "Pendiente";
    }

    public String getNumeroEnvio() {
        return numeroEnvio;
    }

    public String getDestino() {
        return destino;
    }

    public double getDistancia() {
        return distancia;
    }

    public double getPeso() {
        return peso;
    }

    public double getCosto() {
        return costo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    // Método para calcular el costo basado en la distancia y el peso
    private double calcularCosto() {
        return distancia * 1.5 + peso * 0.5; // Ejemplo: 1.5 por km + 0.5 por kg
    }

    @Override
    public String toString() {
        return "Envio: " + numeroEnvio + " | Destino: " + destino + " | Distancia: " + distancia + " km | Peso: " + peso +
                " kg | Costo: $" + costo + " | Estado: " + estado;
    }
}

// Clase para representar un camión
class Camion {
    private String matricula;
    private double capacidadMaxima;  // en kilogramos

    public Camion(String matricula, double capacidadMaxima) {
        this.matricula = matricula;
        this.capacidadMaxima = capacidadMaxima;
    }

    public String getMatricula() {
        return matricula;
    }

    public double getCapacidadMaxima() {
        return capacidadMaxima;
    }

    @Override
    public String toString() {
        return "Camion: " + matricula + " | Capacidad Máxima: " + capacidadMaxima + " kg";
    }
}

// Clase principal para gestionar la logística
class Logistica {
    private ArrayList<Envio> envios;
    private ArrayList<Camion> camiones;

    public Logistica() {
        envios = new ArrayList<>();
        camiones = new ArrayList<>();
    }

    // Registrar un nuevo envío
    public void registrarEnvio(String numeroEnvio, String destino, double distancia, double peso) {
        envios.add(new Envio(numeroEnvio, destino, distancia, peso));
        System.out.println("Envío registrado: " + numeroEnvio);
    }

    // Asignar un camión a un envío
    public void asignarCamion(String numeroEnvio, String matriculaCamion) {
        Envio envio = buscarEnvio(numeroEnvio);
        Camion camion = buscarCamion(matriculaCamion);

        if (envio != null && camion != null) {
            if (envio.getPeso() <= camion.getCapacidadMaxima()) {
                envio.setEstado("En tránsito");
                System.out.println("Camión " + matriculaCamion + " asignado al envío " + numeroEnvio);
            } else {
                System.out.println("El camión no tiene capacidad suficiente para este envío.");
            }
        } else {
            System.out.println("Envío o camión no encontrado.");
        }
    }

    // Actualizar el estado de un envío
    public void actualizarEstadoEnvio(String numeroEnvio, String nuevoEstado) {
        Envio envio = buscarEnvio(numeroEnvio);
        if (envio != null) {
            envio.setEstado(nuevoEstado);
            System.out.println("Estado del envío " + numeroEnvio + " actualizado a: " + nuevoEstado);
        } else {
            System.out.println("Envío no encontrado.");
        }
    }

    // Método para buscar un envío por su número
    private Envio buscarEnvio(String numeroEnvio) {
        for (Envio envio : envios) {
            if (envio.getNumeroEnvio().equalsIgnoreCase(numeroEnvio)) {
                return envio;
            }
        }
        return null;
    }

    // Método para buscar un camión por su matrícula
    private Camion buscarCamion(String matricula) {
        for (Camion camion : camiones) {
            if (camion.getMatricula().equalsIgnoreCase(matricula)) {
                return camion;
            }
        }
        return null;
    }

    // Agregar un nuevo camión
    public void agregarCamion(String matricula, double capacidadMaxima) {
        camiones.add(new Camion(matricula, capacidadMaxima));
        System.out.println("Camión agregado: " + matricula);
    }

    // Mostrar todos los envíos
    public void mostrarEnvios() {
        System.out.println("\n--- Lista de Envíos ---");
        for (Envio envio : envios) {
            System.out.println(envio);
        }
    }

    // Mostrar todos los camiones
    public void mostrarCamiones() {
        System.out.println("\n--- Lista de Camiones ---");
        for (Camion camion : camiones) {
            System.out.println(camion);
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Logistica logistica = new Logistica();

        while (true) {
            System.out.println("\n--- Menú de Logística ---");
            System.out.println("1. Registrar Envío");
            System.out.println("2. Asignar Camión");
            System.out.println("3. Actualizar Estado de Envío");
            System.out.println("4. Agregar Camión");
            System.out.println("5. Mostrar Envíos");
            System.out.println("6. Mostrar Camiones");
            System.out.println("7. Salir");
            System.out.print("Elige una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    System.out.print("Número de envío: ");
                    String numeroEnvio = scanner.nextLine();
                    System.out.print("Destino: ");
                    String destino = scanner.nextLine();
                    System.out.print("Distancia (km): ");
                    double distancia = scanner.nextDouble();
                    System.out.print("Peso (kg): ");
                    double peso = scanner.nextDouble();
                    logistica.registrarEnvio(numeroEnvio, destino, distancia, peso);
                    break;
                case 2:
                    System.out.print("Número de envío: ");
                    numeroEnvio = scanner.nextLine();
                    System.out.print("Matrícula del camión: ");
                    String matriculaCamion = scanner.nextLine();
                    logistica.asignarCamion(numeroEnvio, matriculaCamion);
                    break;
                case 3:
                    System.out.print("Número de envío: ");
                    numeroEnvio = scanner.nextLine();
                    System.out.print("Nuevo estado: ");
                    String nuevoEstado = scanner.nextLine();
                    logistica.actualizarEstadoEnvio(numeroEnvio, nuevoEstado);
                    break;
                case 4:
                    System.out.print("Matrícula del camión: ");
                    String matricula = scanner.nextLine();
                    System.out.print("Capacidad máxima del camión (kg): ");
                    double capacidadMaxima = scanner.nextDouble();
                    logistica.agregarCamion(matricula, capacidadMaxima);
                    break;
                case 5:
                    logistica.mostrarEnvios();
                    break;
                case 6:
                    logistica.mostrarCamiones();
                    break;
                case 7:
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }
}
