import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

// Clase para representar una evaluación
class Evaluacion {
    private double puntuacion; // Puntuación de la evaluación
    private Date fecha;

    public Evaluacion(double puntuacion) {
        this.puntuacion = puntuacion;
        this.fecha = new Date(); // Fecha actual
    }

    public double getPuntuacion() {
        return puntuacion;
    }

    public Date getFecha() {
        return fecha;
    }

    @Override
    public String toString() {
        return "Puntuación: " + puntuacion + " | Fecha: " + fecha;
    }
}

// Clase para representar un empleado
class Empleado {
    private String nombre;
    private String id;
    private double salarioBase;
    private ArrayList<Evaluacion> evaluaciones;

    public Empleado(String nombre, String id, double salarioBase) {
        this.nombre = nombre;
        this.id = id;
        this.salarioBase = salarioBase;
        this.evaluaciones = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public String getId() {
        return id;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void agregarEvaluacion(double puntuacion) {
        evaluaciones.add(new Evaluacion(puntuacion));
        System.out.println("Evaluación registrada para: " + nombre);
    }

    public double calcularBonificacion() {
        double sumaPuntuaciones = 0;
        for (Evaluacion eval : evaluaciones) {
            sumaPuntuaciones += eval.getPuntuacion();
        }
        double promedio = evaluaciones.size() > 0 ? sumaPuntuaciones / evaluaciones.size() : 0;
        return salarioBase * (promedio / 100); // Bonificación basada en promedio
    }

    @Override
    public String toString() {
        return "Empleado: " + nombre + " | ID: " + id + " | Salario Base: $" + salarioBase + " | Bonificación: $" + calcularBonificacion();
    }

    public void mostrarEvaluaciones() {
        System.out.println("Evaluaciones para " + nombre + ":");
        for (Evaluacion eval : evaluaciones) {
            System.out.println(eval);
        }
    }
}

// Clase para gestionar empleados
class GestionEmpleados {
    private ArrayList<Empleado> empleados;

    public GestionEmpleados() {
        empleados = new ArrayList<>();
    }

    // Agregar un nuevo empleado
    public void agregarEmpleado(String nombre, String id, double salarioBase) {
        empleados.add(new Empleado(nombre, id, salarioBase));
        System.out.println("Empleado agregado: " + nombre);
    }

    // Registrar evaluación a un empleado
    public void registrarEvaluacion(String idEmpleado, double puntuacion) {
        for (Empleado emp : empleados) {
            if (emp.getId().equalsIgnoreCase(idEmpleado)) {
                emp.agregarEvaluacion(puntuacion);
                return;
            }
        }
        System.out.println("Empleado no encontrado.");
    }

    // Mostrar información de los empleados
    public void mostrarEmpleados() {
        System.out.println("\n--- Lista de Empleados ---");
        for (Empleado emp : empleados) {
            System.out.println(emp);
        }
    }

    // Mostrar evaluaciones de un empleado
    public void mostrarEvaluaciones(String idEmpleado) {
        for (Empleado emp : empleados) {
            if (emp.getId().equalsIgnoreCase(idEmpleado)) {
                emp.mostrarEvaluaciones();
                return;
            }
        }
        System.out.println("Empleado no encontrado.");
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GestionEmpleados gestion = new GestionEmpleados();

        while (true) {
            System.out.println("\n--- Menú de Gestión de Empleados ---");
            System.out.println("1. Agregar Empleado");
            System.out.println("2. Registrar Evaluación");
            System.out.println("3. Mostrar Empleados");
            System.out.println("4. Mostrar Evaluaciones de un Empleado");
            System.out.println("5. Salir");
            System.out.print("Elige una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    System.out.print("Nombre del empleado: ");
                    String nombre = scanner.nextLine();
                    System.out.print("ID del empleado: ");
                    String id = scanner.nextLine();
                    System.out.print("Salario base del empleado: ");
                    double salarioBase = scanner.nextDouble();
                    gestion.agregarEmpleado(nombre, id, salarioBase);
                    break;
                case 2:
                    System.out.print("ID del empleado: ");
                    String idEmpleado = scanner.nextLine();
                    System.out.print("Puntuación de la evaluación: ");
                    double puntuacion = scanner.nextDouble();
                    gestion.registrarEvaluacion(idEmpleado, puntuacion);
                    break;
                case 3:
                    gestion.mostrarEmpleados();
                    break;
                case 4:
                    System.out.print("ID del empleado: ");
                    idEmpleado = scanner.nextLine();
                    gestion.mostrarEvaluaciones(idEmpleado);
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }
}
